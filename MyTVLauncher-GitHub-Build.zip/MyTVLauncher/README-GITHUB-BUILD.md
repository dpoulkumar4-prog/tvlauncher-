# Build the APK using GitHub Actions (no laptop needed)

1. On your Vivo phone, open https://github.com in Chrome and sign in (create a free account if needed).
2. Create a **New repository**. Name it `MyTVLauncher`. Choose **Public** or **Private**, then create it.
3. Open the repository and use **Add file → Upload files**. Extract `MyTVLauncher-Android-Project.zip` on your phone first, then upload the *contents* of the `MyTVLauncher` folder (including the hidden `.github` folder and its `workflows/build-apk.yml` file). If the GitHub mobile page cannot upload a folder, use GitHub's web upload to add the files in batches; make sure `.github/workflows/build-apk.yml` is included.
4. Commit the uploaded files to the `main` branch.
5. In the repository, open **Actions**. Select **Build MyTVLauncher APK**. If prompted, enable workflows. Tap **Run workflow → Run workflow**.
6. Wait for the run to finish with a green check. Open that run, scroll to **Artifacts**, and download `MyTVLauncher-debug-apk`.
7. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
8. Transfer `app-debug.apk` to your TV and install it. You may need to allow your file manager to install unknown apps.

Notes:
- GitHub Actions compiles the source in GitHub's cloud; Android Studio is not needed on your phone.
- This is a debug APK for testing, not a Play Store release.
- Keep the original TV launcher available until you have tested the new launcher. Your TV firmware may restrict replacing the default Home app.
- If the build fails, open the failed Actions run and share the error log so it can be fixed.
